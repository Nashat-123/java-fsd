package phase1;

public class AccessSpecifierDemo {
	int defaultVar=10;
    private int privateVar = 1;
    protected int protectedVar = 2;
    public int publicVar = 3;
    void defaultMethod()
    {
    	System.out.println("This is a default method.");
    }
    private void privateMethod() {
        System.out.println("This is a private method.");
    }
    
    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }
    
    public void publicMethod() {
        System.out.println("This is a public method.");
    }
    
    public static void main(String[] args) {
        AccessSpecifierDemo obj = new AccessSpecifierDemo();
        //Private:The access level of a private modifier is only within the class. It cannot be accessed from outside the class.
        System.out.println("Accessing default variable: " + obj.defaultVar);//if no accessspecifier is declared it comes under Default Specifier  
        System.out.println("Accessing private variable: " + obj.privateVar); // Error: private variable cannot be accessed from outside the class
        //Protected: The access level of a protected modifier is within the package and outside the package through child class. If you do not make the child class, it cannot be accessed from outside the package
        System.out.println("Accessing protected variable: " + obj.protectedVar); // Output: 2
        //Public: The access level of a public modifier is everywhere. It can be accessed from within the class, outside the class, within the package and outside the package.
        System.out.println("Accessing public variable: " + obj.publicVar); // Output: 3
        obj.privateMethod(); // Error: private method cannot be accessed from outside the class
        obj.protectedMethod(); // Output: "This is a protected method."
        obj.publicMethod(); // Output: "This is a public method."
        obj.defaultMethod();
    }
}
