package package1;

public class BinarySearch {

	public static void main(String[] args) {
		
		int[] numbers = {10, 20, 30, 40, 50, 60};
        int target = 60;

        int index = binarySearch(numbers, target);

        if (index != -1) {
            System.out.println("Target found at index " + index);
        } else {
            System.out.println("Target not found");
        }
	}
	public static int binarySearch(int[] array, int target) {
        int left = 0;
        int right = array.length-1;

        while (left <= right) 
        {
            int mid = (left+right) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if the target is found
            }

            if (array[mid] < target) {
                left = mid + 1; // Search the right half of the array
            } else {
                right = mid - 1; // Search the left half of the array
            }
        }

        return -1; // Return -1 if the target is not found
    }
}
