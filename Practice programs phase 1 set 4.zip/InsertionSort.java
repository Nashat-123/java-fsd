package package1;

import java.util.Arrays;

public class InsertionSort {
	 public static void main(String[] args) {
	        int[] numbers = {64, 34, 25, 12, 22, 11, 90};
	        System.out.println("Original array: " + Arrays.toString(numbers));
	        
	        InsertionSort(numbers);

	        System.out.println("Sorted array: " + Arrays.toString(numbers));
	    }

	private static void InsertionSort(int[] numbers) {
		for(int i=1;i<numbers.length;i++)
		{
			int k=numbers[i];
			int j=i-1;
			while(j>=0 && k<numbers[j])
			{
				numbers[j+1]=numbers[j];
				numbers[j]=k;
				 j--;
			}
		}
		
	}
}
