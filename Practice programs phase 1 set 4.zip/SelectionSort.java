package package1;

import java.util.Arrays;

public class SelectionSort {
    public static void selectionSort(int[] array) {
        int n = array.length;

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;

            // Find the index of the minimum element in the unsorted part of the array
            for (int j = i + 1; j < n; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the minimum element with the first element of the unsorted part
            if(i!=minIndex)
            {
            	 int temp = array[minIndex];
                 array[minIndex] = array[i];
                 array[i] = temp;
            }
           
        }
    }

    public static void main(String[] args) {
        int[] numbers = {64, 25, 92, 22, 11};
        System.out.println("Original array: " + Arrays.toString(numbers));

        selectionSort(numbers);

        System.out.println("Sorted array: " + Arrays.toString(numbers));
    }
}

