package package1;

public class ExponentialSearch {
    public static int exponentialSearch(int[] array, int target) {
        if (array[0] == target) {
            return 0; // Return 0 if the target is found at the first element
        }

        int i = 1;
        while (i < array.length && array[i] <= target) {
            i *= 2; // Double the value of i for each iteration
        }

        return binarySearch(array, target, i / 2, Math.min(i, array.length - 1));
    }

    public static int binarySearch(int[] array, int target, int left, int right) {
        while (left <= right) {
            int mid = (left + right) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if the target is found
            }

            if (array[mid] < target) {
                left = mid + 1; // Search the right half of the array
            } else {
                right = mid - 1; // Search the left half of the array
            }
        }

        return -1; // Return -1 if the target is not found
    }

    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50, 60};
        int target = 60;

        int index = exponentialSearch(numbers, target);

        if (index != -1) {
            System.out.println("Target found at index " + index);
        } else {
            System.out.println("Target not found");
        }
    }
}

