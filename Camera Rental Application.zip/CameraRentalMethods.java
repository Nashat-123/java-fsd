package MainProject;

import java.util.*;

public class CameraRentalMethods 
{
	
	protected  List<Camera> cameraList;
    private List<User> userList;
    public CameraRentalMethods() 
    {
        cameraList = new ArrayList<>();
        userList = new ArrayList<>();
    }
    public void addBefore()
    {
    	cameraList.add(new Camera("Samsung","DS123",500));
    	cameraList.add(new Camera("Sony","HD214",500));
    	cameraList.add(new Camera("Panasonic","XC",500.0));
    	cameraList.add(new Camera("Canon","XLR",500.0));
    	cameraList.add(new Camera("Fujitsu","J5",500.0));
    	cameraList.add(new Camera("Sony","HD226",500.0));
    	cameraList.add(new Camera("LG","L123",500.0));
    	cameraList.add(new Camera("Canon","XPL",500.0));
    	cameraList.add(new Camera("Chroma","CT",500.0));
    	
    }
    public void addCamera(Camera camera)
    {
        cameraList.add(camera);
        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST");
        return;
    }
    public void addUser(User user)
    {
        userList.add(user);
    }
    public void removeCamera(int cameraId) {
        Iterator<Camera> iterator = cameraList.iterator();
        while (iterator.hasNext()) {
            Camera camera = iterator.next();
            if (camera.getId() == cameraId) {
                iterator.remove();
                System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
                return;
            }
        }
        System.out.println("Camera with ID " + cameraId + " not found in the list.");
    }
    public void displayAvailableCameras() 
    {
    	if (cameraList.isEmpty()) {
            System.out.println("No cameras are currently available for rent.");
        } 
    	else
    	{
    	    System.out.println("===============================================================");
    		System.out.println("Camera ID    Brand      Model     Price (Per Day)   Status");
    		System.out.println("===============================================================");
    	    for (Camera camera : cameraList) {
    	        System.out.printf("%-12d %-10s %-10s %-16.2f %s%n",
    	                camera.getId(), camera.getBrand(), camera.getModel(),
    	                camera.getRentAmount(), camera.isRented() ? "Rented" : "Available");
    	    }
    	    System.out.println("===============================================================");
    	}
       
    }
    public void displayMyCameras(String username)
    {
    	boolean found=false;
    	for(Camera camera:cameraList)
    	{
    		if(camera.getRenter().equals(username))
    		{
    			found =true;
    			break;
    		}
    	}
    	if(found)
    	{
    		System.out.println("===============================================================");
     		System.out.println("Camera ID    Brand      Model     Price (Per Day)  Status");
        	System.out.println("===============================================================");
        	for(Camera camera : cameraList)
        	{
        		if(camera.getRenter().equals(username))
            	{
        			 System.out.printf("%-12d %-10s %-10s %-16.2f %s%n",
         	                camera.getId(), camera.getBrand(), camera.getModel(),
         	                camera.getRentAmount(), camera.isRented() ? "Rented" : "Available");
            	}
        	}
        	System.out.println("===============================================================");
    	}
    	else
    	{
    		System.out.println("Till Now no cameras were added by you");
    	}
    }
    public void rentCamera(User user, int cameraId) throws InsufficientBalanceException
    {
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraId) {
            	if (camera.isRented()) {
                    System.out.println("Camera is already rented.");
                }
            	else{
            		double rentAmount = camera.getRentAmount();

                    if (user.hasSufficientBalance(rentAmount)) {
                        user.deductBalance(rentAmount);
                        camera.rent();
                        System.out.println("Your transaction for camera - "+camera.getBrand()+" "+camera.getModel()+" with rent INR."+camera.getRentAmount()+" has successfully completed");
                    } 
                    else{
                        
                    	throw new InsufficientBalanceException("Insufficient balance in your wallet to rent the camera.");
                    }
            	}
                
                return;
            }
        }
        System.out.println("Invalid camera ID.");
    }
}

