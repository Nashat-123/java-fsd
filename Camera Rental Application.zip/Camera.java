package MainProject;
import java.util.*;
public class Camera {

	private static int counter = 0;
    private int id;
    private String brand;
    private String model;
    private double rentAmount;
    public boolean rented;
    public String renter;
    Camera(String brand, String model, double rentAmount)
    {
    	this.id = ++counter;
        this.brand = brand;
        this.model = model;
        this.rentAmount = rentAmount;
        this.rented = false;
        this.renter="";
    }
    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentAmount() {
        return rentAmount;
    }
    public boolean isRented() {
        return rented;
    }

    public void rent() {
        this.rented = true;
    }
    public String getRenter()
    {
    	return this.renter;
    }
    public void setRenter(String renter)
    {
    	this.renter=renter;
    }
    public void returnCamera() {
        this.rented = false;
      
    }

}
