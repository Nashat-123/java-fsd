package MainProject;
import java.util.InputMismatchException;
import java.util.Scanner;
public class CameraRentalApp extends CameraRentalMethods
{
	public static void main(String[] args)
	{
		//cameraList.add(new Camera("Samsung","fr3",1000.0));
		Scanner sc = new Scanner(System.in);
		CameraRentalMethods app = new CameraRentalMethods();
		app.addBefore();
		System.out.println("+----------------------------+");
		 System.out.println("|WELCOME TO CAMERA RENTAL APP|");
		 System.out.println("+----------------------------+");
		 System.out.println("PLEASE LOGIN TO CONTINUE");
	     System.out.print("USERNAME - ");
	     String username = sc.nextLine();
	     System.out.print("PASSWORD ");
	     String password = sc.nextLine();
	     if (username.equals("admin") && password.equals("admin123"))
	     {
	    	 User user = new User(username, 500);
	    	 app.addUser(user);
	    	 int exit1 = 1;
	    	 while(exit1!=0)
	    	 {
	    		 System.out.println("1. MY CAMERA");
	             System.out.println("2. RENT A CAMERA");
	             System.out.println("3. VIEW ALL CAMERAS");
	             System.out.println("4. MY WALLET");
	             System.out.println("5. EXIT");
	             int choice = sc.nextInt();
	    		 switch(choice)
	    		 {
	    		 	case 1:
	    		 		int exit2=1;
	    		 		while(exit2!=0)
	    		 		{
	    		 			System.out.println("1. ADD");
	                        System.out.println("2. REMOVE");
	                        System.out.println("3. VIEW MY CAMERAS");
	                        System.out.println("4. GO TO PREVIOUS MENU");
	                        int subChoice=sc.nextInt();
	    		 			switch(subChoice)
	    		 			{
	    		 				case 1:
	    		 					System.out.print("ENTER THE CAMERA BRAND - ");
	    		 					sc.nextLine();
	                                String brand = sc.nextLine();
	                                System.out.print("ENTER THE MODEL - ");
	                                String model = sc.nextLine();
	                                System.out.print("ENTER THE PER DAY PRICE (INR) - ");
	                                double rentAmount = sc.nextDouble();
	                                sc.nextLine(); 
	                                Camera camera = new Camera(brand, model, rentAmount);
	                                app.addCamera(camera);
	                                camera.setRenter(user.getUsername());
	                                break;
	    		 				case 2:
	    		 					app.displayAvailableCameras();
	    		 					System.out.print("ENTER THE CAMERA ID TO REMOVE ");
	                                int cameraId = sc.nextInt();
	                                sc.nextLine();
	                                app.removeCamera(cameraId);
	                                break;
	    		 				case 3:
	    		 					System.out.println("YOUR RENTED CAMERAS:");
	    		 					
	    		 					app.displayMyCameras(user.getUsername());
									break;
	    		 				case 4:exit2=0;
	    		 						break;
	    		 			}
	    		 			
	    		 		}
	    		 		break;
	    		 		case 2:
	    		 			app.displayAvailableCameras();
                            System.out.print("Enter the camera ID you want to rent: ");
                            int rentCameraId = sc.nextInt();
                            try {
                            	app.rentCamera(user, rentCameraId);
                            }	
                            catch (InsufficientBalanceException e) {
                            	System.out.println(e.getMessage());
                            }
                            break;
	    		 		case 3:
	    		 			 app.displayAvailableCameras();
	                         break;
	    		 		case 4:
	    		 			System.out.println("YOUR CURRENT WALLET BALANCE IS INR " + user.getWalletBalance());
	                        try
	                        {
	                        	System.out.print("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET? (1.YES 2.NO) - ");	
	                        	int depositChoice = sc.nextInt();
		                        sc.nextLine(); // Consume the newline character
		                        if (depositChoice == 1) {
		                            System.out.print("ENTER THE AMOUNT (INR) - ");
		                            double depositAmount = sc.nextDouble();
		                            user.deposit(depositAmount);
		                            //System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE INR "
		                              //      + user.getWalletBalance());
		                        } else if (depositChoice != 2) {
		                            System.out.println("Invalid choice.");
		                        }

	                        }
	                        catch (InputMismatchException e) {
                            	System.out.println("Exception raised scince you entered something other than 1 and 2 ");
                            	System.out.println("Please enter 1 which means YES or 2 which means NO.");
                            	sc.nextLine(); 
                            }
	                        
	                        break;
	    		 		case 5:
	    		 			exit1=0;
	    		 			break;
	    		 }
	    	 }
	    	 closeApp();
	     }
	}
	public static void closeApp()
	{
		System.out.println("============Thank you=============");
		System.out.println("Closing The Application");
	}
}
