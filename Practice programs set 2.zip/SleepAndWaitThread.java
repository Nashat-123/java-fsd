package phase1;

public class SleepAndWaitThread {
	public static void main(String args[]) {
	 Task1 th1 = new Task1();
	 Thread t1 = new Thread(th1);
     Thread t2 = new Thread(new Task2());

     t1.start();
     t2.start();
	}
}
class Task1 implements Runnable {
    @Override
    public void run() {
        System.out.println("Task1 started");

        try {
            Thread.sleep(3000); // Sleep for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Task1 finished");
    }
}

class Task2 implements Runnable {
    @Override
    public void run() {
        System.out.println("Task2 started");

        synchronized (this) {
            try {
                this.wait(1000); // Wait indefinitely
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Task2 finished");
    }
}
