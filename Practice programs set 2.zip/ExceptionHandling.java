package phase1;

class InvalidEmailException extends Exception {
    public InvalidEmailException(String message) {
        super(message);
    }
}
public class ExceptionHandling {

	public static void main(String[] args) {
		
		try {
            String email = "invalid-email";
            if (!email.contains("@")) {
            	System.out.println("This is try block");
                throw new InvalidEmailException("Error: Invalid email format.");
            }
            else {
                System.out.println("The email is: " + email);
            }
        }
        catch (InvalidEmailException e)
		{
        	System.out.println("This is catch block");
            System.out.println(e.getMessage());
        }
		finally
		{
			System.out.println("This is finally block,Java finally block is always executed whether an exception is handled or not");
		}

	}

}
