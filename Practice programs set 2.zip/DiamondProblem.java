package phase1;
interface Square
{
	default void getArea(double s)
	{
		System.out.println("Method from Square interface");
		System.out.println("Area of square is "+s+"*"+s+" :"+s*s);
	}
}
interface Rectangle
{
	default void getArea(double l,double b)
	{
		System.out.println("Method from Rectangle interface");
		System.out.println("Area of square is "+l+"*"+b+" :"+l*b);
	}
}
public class DiamondProblem implements Square,Rectangle
{
	public void getArea(double s,double l,double b)
	{
		Square.super.getArea(s);
		Rectangle.super.getArea(l, b);
	}

	public static void main(String[] args) {
		// when we call getArea() method compiler wont get confused
		DiamondProblem obj1 = new DiamondProblem();
		obj1.getArea(5,6,7);
	}
	
}
