package phase1;

public class TryCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = null;
		try
		{
			System.out.println("The length of string is"+s.length());
		}
		catch(NullPointerException e)
		{
			System.out.println("Error : It raises java.lang.NullPointerException");
		}
		finally
		{
			System.out.println("It raises exception because the string length is NUll");
		}
	}

}
