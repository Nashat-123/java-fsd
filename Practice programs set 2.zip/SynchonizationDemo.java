package phase1;
import java.util.Scanner;
class Account
{
	private int balance;
	Account(int balance)
	{
		this.balance = balance;
	}
	public boolean isSufficientBalance(int withdraw)
	{
		if(balance>withdraw)
		{
			return true;
		}
		else
			return false;
	}
	public void withdraw(int amount)
	{
		balance = balance-amount;
		System.out.println("withdrawl money is"+amount);
		System.out.println("your current balance is"+balance);
	}
}
class Customer implements Runnable
{
	private Account account;
	private String name;
	int amount;
	Scanner sc = new Scanner(System.in);
	public Customer(Account account,String name)
	{
		this.account = account;
		this.name = name;
	}
	@Override
	public void run() {
		//if synchronized keyword is not used on account then the execution happen abnormally the account ammount will go in negative
		synchronized(account){
		System.out.println("Enter amount to withdrawl");
		amount = sc.nextInt();
		if(account.isSufficientBalance(amount))
		{
			System.out.println("Name:"+name);
			account.withdraw(amount);
		}
		else
			System.out.println("Insufficient Amount");
	}
	}
}
public class SynchonizationDemo {

	public static void main(String[] args) {
		Account a1 = new Account(1000);
		Customer c1 = new Customer(a1,"Azhar");
		Customer c2 = new Customer(a1,"Nashat");
		Thread t1 = new Thread(c1);
		Thread t2 = new Thread(c2);
		t1.start();
		t2.start();
	}

}
