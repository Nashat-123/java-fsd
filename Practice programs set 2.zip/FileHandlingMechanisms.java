package Files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandlingMechanisms {
    public static void main(String[] args) {
        // Define the file name and path
        String fileName = "example.txt";
        String filePath = "D:\\MPHASIS\\Practice programs\\Phase1\\src\\Files"+fileName;

        // Create the file
        File file = new File(filePath);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.err.println("Error creating file: " + e.getMessage());
        }

        // Write to the file
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write("This is the first line of the file.");
            writer.write(System.lineSeparator());
            writer.write("This is the second line of the file.");
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }

        // Read from the file
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }

        // Update the file
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write("This is the updated first line of the file.");
            writer.write(System.lineSeparator());
            writer.write("This is the updated second line of the file.");
            System.out.println("Successfully updated the file.");
        } catch (IOException e) {
            System.err.println("Error updating file: " + e.getMessage());
        }

        // Read from the file again to verify the update
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }

        // Delete the file
       /*if (file.delete()) {
            System.out.println("File deleted: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }*/
    }
}
