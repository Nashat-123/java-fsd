package phase1;

public class ArraysDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // declare and initialize an integer array
        int[] numbers = { 1, 2, 3, 4, 5 };
        
        // print the length of the array
        System.out.println("Length of the array: " + numbers.length);
        
        // print the elements of the array using a for loop
        System.out.print("Elements of the array: ");
        for (int i = 0; i < numbers.length; i++)
        {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
        
        // create a two-dimensional array
        int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
        
        // print the elements of the two-dimensional array using nested loops
        System.out.println("Elements of the Multi-dimensional array:");
        for (int i = 0; i < matrix.length; i++)
        {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

	}

}
