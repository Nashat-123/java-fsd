package phase1;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char a='Z';
		System.out.println("Value of a: "+a);
		float b=a;
		System.out.println("Value of b: "+b);
		int c=a;
		System.out.println("Value of b: "+c);
		long d=a;
		System.out.println("Value of d: "+d);
		
		double e=a;
		System.out.println("Value of e: "+e);
		
				
		System.out.println("\n");
		//Explicit Type Casting
		System.out.println("Explicit Type Casting");
		float num1 = 6.14f;
        int num2 = (int) num1;
        System.out.println("num1: " + num1); 
        System.out.println("num2: " + num2);


	}

}
