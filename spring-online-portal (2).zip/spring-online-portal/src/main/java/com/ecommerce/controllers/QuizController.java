package com.ecommerce.controllers;


import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.entity.Question;
import com.ecommerce.entity.Quiz;
import com.ecommerce.entity.Score;
import com.ecommerce.repository.QuestionRepo;
import com.ecommerce.repository.QuizRepo;
import com.ecommerce.repository.ScoreRepo;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class QuizController {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	
	@Autowired
	QuizRepo  quizRepo;
	
	@Autowired
	QuestionRepo questionRepo;
	
	@Autowired
    private ScoreRepo scoreRepo;
	
	@GetMapping("/create-quiz")
	public String showNewQuizForm(Model model)
	{
		Quiz quiz = new Quiz();
		model.addAttribute("quiz", quiz);

		return "new-quiz";
	}
	
	@PostMapping("/create-quiz")
	public String addNewQuiz(@ModelAttribute("quiz") Quiz quiz)
	{
		quizRepo.save(quiz);
		return "admin-dashboard";
	}
	
	@GetMapping("/view-quizes")
	public String listQuizes(Model model)
	{
		List<Quiz> quizList = quizRepo.findAll();
		model.addAttribute("quizList", quizList);
		
		return "quiz-list";
	}
	@GetMapping("/addQuiz-questions")
	public String showAddQuestionsForm(@RequestParam Long id, Model model) {
	    Optional<Quiz> quizOptional = quizRepo.findById(id);
	   
	        Quiz quiz = quizOptional.get();
	        List<Question> questionList = questionRepo.findAll();
	        model.addAttribute("quiz", quiz);
	        model.addAttribute("questionList", questionList);
	        return "add-questionsform";
	   
	}
	
	@GetMapping("/addQuizQueries")
	public String addQuestionToQuiz(@RequestParam("question_id") int question_id, @RequestParam("quiz_id") Long quiz_id) {
		String sql = "INSERT INTO QUIZ_QUESTIONS (QUIZ_ID, QUESTION_ID) VALUES (?, ?)";
		try {
			jdbcTemplate.update(sql, quiz_id, question_id);
			return "qadded-success"; // Return the success view
		} catch (Exception e) {
			return "qfailed"; // Return an error view
		}
	}
	
	/*@GetMapping("/showQuiz-Questions")
	public String showQuizQuestions(@RequestParam Long id, Model model) {
		Optional<Quiz> quizOptional = quizRepo.findById(id);
		
			Quiz quiz = quizOptional.get();
			List<Question> questionList = questionRepo.findByQuizId(quiz.getID());
			model.addAttribute("quiz", quiz);
			model.addAttribute("questionList", questionList);
			return "quiz-questions";
		
	}*/
	@GetMapping("/showQuiz-Questions")
	public String showQuizQuestions(@RequestParam Long id, Model model) {
	    Optional<Quiz> quizOptional = quizRepo.findById(id);
	        Quiz quiz = quizOptional.get();
	        Long quizId = quiz.getID();
	        
	        // Execute a custom SQL query to retrieve the associated questions
	        String sql = "SELECT * FROM QUESTIONS q INNER JOIN QUIZ_QUESTIONS qq ON q.ID = qq.QUESTION_ID WHERE qq.QUIZ_ID = ?";
	        List<Question> questionList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Question.class), quizId);
	        
	        model.addAttribute("quiz", quiz);
	        model.addAttribute("questionList", questionList);
	        return "quiz-questions";
	   
	}

	//for user dashboard
	@GetMapping("/available-quizes")
	public String listAvailableQuizes(@RequestParam String username,Model model)
	{
		List<Quiz> quizList = quizRepo.findAll();
		model.addAttribute("quizList", quizList);
		model.addAttribute("username", username);

		return "userQuiz-list";
	}
	
	@GetMapping("/start-quiz")
	public String startQuiz(@RequestParam("id") Long id,@RequestParam("username") String username,Model model)
	{
		 Optional<Quiz> quizOptional = quizRepo.findById(id);
	        Quiz quiz = quizOptional.get();
	        Long quizId = quiz.getID();
	        
	        // Execute a custom SQL query to retrieve the associated questions
	        String sql = "SELECT * FROM QUESTIONS q INNER JOIN QUIZ_QUESTIONS qq ON q.ID = qq.QUESTION_ID WHERE qq.QUIZ_ID = ?";
	        List<Question> questionList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Question.class), quizId);
	        
	        model.addAttribute("quiz", quiz);
	        model.addAttribute("questionList", questionList);
	        model.addAttribute("username",username);
	        return "attempt-quiz";
	   
	}
	
	@PostMapping("/submit-quiz")
	public String submitQuiz(HttpServletRequest request, Model model) {
	    String username = request.getParameter("username");
	    Long quizId = Long.parseLong(request.getParameter("quizId"));

	    // Retrieve the list of questions for the quiz
	    String sql = "SELECT * FROM QUESTIONS q INNER JOIN QUIZ_QUESTIONS qq ON q.ID = qq.QUESTION_ID WHERE qq.QUIZ_ID = ?";
	    List<Question> questionList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Question.class), quizId);

	    int score = 0;
	    for (Question question : questionList) {
	        //String answer = request.getParameter(String.valueOf(question.getID()));
	    	String answer = request.getParameter(question.getID().toString());

	        if (answer != null && answer.equals(question.getAnswer())) {
	            score++;
	        }
	    }

	    // Create a new Score object and save it to the database
	    Score scoreObj = new Score();
	    scoreObj.setUserName(username);
	    scoreObj.setQuizId(quizId);
	    scoreObj.setScore(score);
	    scoreRepo.save(scoreObj);

	    model.addAttribute("score", score);
	    model.addAttribute("username",username);
	    model.addAttribute("quizId",quizId);
	    return "quiz-result";
	}

	@GetMapping("/view-scoreboard")
	public String viewScoreboard(Model model) {
	    List<Score> scoreList = scoreRepo.findAll();
	    // Sort the score list in descending order based on scores
	    scoreList.sort(Comparator.comparingInt(Score::getScore).reversed());
	    model.addAttribute("scoreList", scoreList);
	    return "scoreboard";
	}

	
}
