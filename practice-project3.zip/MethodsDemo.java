package phase1;
import java.util.Scanner;
public class MethodsDemo {
	int val=50;
	//static method
	public static void greet()
	{
		System.out.println("Hello this is Method Demonstration Program");
	}
	public int difference(int a,int b)
	{
		return a-b;
	}
	//call by value
	public int changeVal(int k)
	{
		val=k*500;
		return val;
	}
	//Method Overloading
	public int add(int a,int b)
	{
		return a+b;
	}
	public double add(double a,double b)
	{
		return a+b;
	}
	public String add(String a,String b)
	{
		return a+" "+b;
	}
	public static void main(String args[])
	{
		MethodsDemo.greet();
		MethodsDemo obj1 = new MethodsDemo();
		System.out.println("The Difference of two numbers is "+obj1.difference(200, 100));
		System.out.println("The value of variable val before changing :"+obj1.val);
		System.out.println("The value of val after changing :"+obj1.changeVal(20));
		System.out.println("Method Overloading");
		System.out.println("add two integers :"+obj1.add(4, 9));
		System.out.println("add two double values :"+obj1.add(5.9, 6.3));
		System.out.println("concatinate two strings :"+obj1.add("End Of", "Program"));
	}
	
}
