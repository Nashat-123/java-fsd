package phase1;
import java.util.*;
public class CollectionsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating arraylist
		System.out.println("ArrayList");
		ArrayList<String> names = new ArrayList<>();
	    names.add("Azhar");
	    names.add("Faiz");
	    names.add("Nashat");
	        
	    // print the names using a for-each loop
	    System.out.println("Names:");
	    for (String name : names) {
	          System.out.println(name);
	    }
	    // create a Vector of integers
        Vector<Integer> vector = new Vector<>();
        vector.add(10);
        vector.add(20);
        vector.add(30);
        System.out.println(vector);
        //creating linked list
        System.out.println("\n");
	    System.out.println("LinkedList");
        LinkedList<String> linkedList = new LinkedList<>();
        linkedList.add("nashat");
        linkedList.add("fatima");
        linkedList.add("Azhar");
        Iterator<String> itr=linkedList.iterator();  
	    while(itr.hasNext()){  
	    System.out.println(itr.next());
	    }
	    // create a HashSet of integers
	    System.out.println("\n");
	    System.out.println("HashSet");
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(10);
        hashSet.add(20);
        hashSet.add(30);
        System.out.println(hashSet);
        //creating linkedhashset
	    System.out.println("\n");
	    System.out.println("LinkedHashSet");
	    LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	    set2.add(11);  
        set2.add(13);  
        set2.add(12);
        set2.add(14);	       
	    System.out.println(set2);


	        
	}

}
