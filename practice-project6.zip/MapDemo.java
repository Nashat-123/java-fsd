package phase1;
import java.util.*;
public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create a HashMap of integers and strings
        HashMap<Integer, String> hashMap = new HashMap<>();
        hashMap.put(10, "John");
        hashMap.put(20, "Mary");
        hashMap.put(30, "Peter");
        System.out.println("\nThe elements of Hashmap are ");  
	    for(Map.Entry m:hashMap.entrySet())
	    {    
	    	System.out.println(m.getKey()+" "+m.getValue());    

	    }
	 // create a Hashtable of integers and strings
        Hashtable<Integer, String> hashtable = new Hashtable<>();
        hashtable.put(10, "John");
        hashtable.put(20, "Mary");
        hashtable.put(30, "Peter");
        System.out.println("\nThe elements of HashTable are ");  
	    for(Map.Entry n:hashtable.entrySet())
	    {    
	       System.out.println(n.getKey()+" "+n.getValue());    
	    }
	 // create a TreeMap of integers and strings
        TreeMap<Integer, String> treeMap = new TreeMap<>();
        treeMap.put(10, "John");
        treeMap.put(20, "Mary");
        treeMap.put(30, "Peter");
        System.out.println("\nThe elements of TreeMap are ");  
	    for(Map.Entry l:treeMap.entrySet())
	    {    
	       System.out.println(l.getKey()+" "+l.getValue());    
	    }    
	      


	}
}
