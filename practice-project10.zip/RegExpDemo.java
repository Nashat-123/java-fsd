package phase1;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegExpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create a pattern to match a date string in the format "dd/mm/yyyy"
        Pattern pattern = Pattern.compile("(\\d{2})/(\\d{2})/(\\d{4})");
        
        // create a matcher for the pattern and a sample input string
        Matcher matcher = pattern.matcher("Today is 07/05/2023");
        
        // check if the pattern matches the input string
        if (matcher.find()) 
        {
            // get the matched groups and print them
            String day = matcher.group(1);
            String month = matcher.group(2);
            String year = matcher.group(3);
            System.out.println("Match found: " + day + "-" + month + "-" + year);
        }
        else 
        {
            System.out.println("No match found");
        }
		
	}

}
