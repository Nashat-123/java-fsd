package package1;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Enqueuing elements into the queue
        queue.add(1);
        queue.add(2);
        queue.add(3);

        // Printing the queue
        System.out.println("Queue: " + queue);

        // Dequeuing an element from the queue
        int dequeuedElement = queue.remove();
        System.out.println("Dequeued element: " + dequeuedElement);

        // Printing the queue after dequeuing
        System.out.println("Queue after dequeuing: " + queue);

        // Peeking at the front element of the queue
        int frontElement = queue.peek();
        System.out.println("Front element: " + frontElement);

        // Enqueuing more elements into the queue
        queue.add(4);
        queue.add(5);

        // Printing the queue after enqueuing
        System.out.println("Queue after enqueuing: " + queue);
    }
}
