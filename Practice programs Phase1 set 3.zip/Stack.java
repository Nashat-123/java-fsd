package package1;

import java.util.Arrays;

public class Stack
{
    private int[] elements;
    private int top;

    public Stack(int capacity) {
        elements = new int[capacity];
        top = -1;
    }

    public void push(int element) {
        if (top == elements.length - 1) {
            throw new RuntimeException("Stack is full");
        }
        elements[++top] = element;
    }

    public int pop() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }
        return elements[top--];
    }

    public int peek() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }
        return elements[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public static void main(String[] args) {
        Stack stack = new Stack(5);

        // Pushing elements onto the stack
        stack.push(1);
        stack.push(2);
        stack.push(3);

        // Printing the stack
        System.out.println("Stack: " + Arrays.toString(stack.elements));

        // Popping an element from the stack
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        // Printing the stack after popping
        System.out.println("Stack after popping: " + Arrays.toString(stack.elements));

        // Peeking at the top element of the stack
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);

        // Pushing more elements onto the stack
        stack.push(4);
        stack.push(5);

        // Printing the stack after pushing
        System.out.println("Stack after pushing: " + Arrays.toString(stack.elements));
    }
}

