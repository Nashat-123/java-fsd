package package1;

public class KthSmallestElement {

	public static void main(String[] args) {
		int a[] = new int[] {12, 3, 5, 7, 4, 19, 26};
		KthSmallestElement ele = new KthSmallestElement();
		int k=4;
		int element = ele.getKthSmallestElement(a,k,0,a.length-1);
		System.out.println("4th smallest element is:"+element);

	}

	private int getKthSmallestElement(int[] a, int k, int low, int high) 
	{
		int pivotpoint = getPivotPoint(a,low,high);
		if(pivotpoint == k-1)
			return a[pivotpoint];
		else if(pivotpoint < k-1)
		{
			return getKthSmallestElement(a,k,pivotpoint+1,high);
		}
		else
			return getKthSmallestElement(a,k,low,pivotpoint-1);
		
	}

	private int getPivotPoint(int[] a, int low, int high)
	{
		int pivotelement = a[high];
		int pivotpoint = low;
		for(int i=low;i<=high;i++)
		{
			if(a[i]<pivotelement)
			{
				int temp = a[pivotpoint];
				a[pivotpoint]=a[i];
				a[i]=temp;
				pivotpoint++;
			}
			
		}
		int temp=a[high];
		a[high]=a[pivotpoint];
		a[pivotpoint]=temp;
		return pivotpoint;
	}

}
