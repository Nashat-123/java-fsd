package phase1;

public class InnerClassDemo {
	private int outerVar = 10;
    
    public void outerMethod() {
        System.out.println("Outer class method called.");
        
        // create an instance of the inner class and call its method
        InnerClass inner = new InnerClass();
        inner.innerMethod();
    }
    
    // inner class
    private class InnerClass {
        private int innerVar = 20;
        
        public void innerMethod() {
            System.out.println("Inner class method called.");
            System.out.println("Outer class variable value: " + outerVar);
            System.out.println("Inner class variable value: " + innerVar);
        }
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClassDemo outerClassObj = new InnerClassDemo();
		outerClassObj.outerMethod();
	}

}
