package phase1;
class ParConstructor
{
	String name;
	int age;
	//parameterized constructor
	ParConstructor(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public void show()
	{
		System.out.println("Name of Student is "+name+" age:"+age);
	}
}

public class ConstructorDemo {
	String name;
	int age;
	//Default constructor
	public void show()
	{
		System.out.println("Name of Student is "+name+" age:"+age);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorDemo obj1 = new ConstructorDemo();
		System.out.println("By using Default Constructor");
		obj1.show();
		ParConstructor obj2 = new ParConstructor("Ruhi",7);
		System.out.println("By using Parameterised Constructor");
		obj2.show();
	}

}
